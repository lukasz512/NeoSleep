# SPEC-0034: Environment Strategy (Dev / Staging / Prod)

Status: Draft  
Owner: Neo Sleep Care  
Apps/Modules: repo  
Milestone: Phase 2

## 1) Goal
Formalize environment separation so that staging is safe and prod is isolated.

## 2) Requirements
- Separate env files
- Separate OAuth credentials
- Separate Notion DB (dev/prod)
- Feature flag "beta"

## 3) DoD
- Staging deploy possible
- No prod secrets in dev

## 4) Documentation updates
- RUNBOOK_LOCAL_DEV (env vars)
- Deployment / env matrix

Date: 2026-02-18
