# SPEC-XXXX: <Feature name>

Status: Draft | Ready | In Progress | Done  
Owner: <name>  
Apps/Modules: <rep/admin/website/portal/bff>  
Milestone: MVP | Phase 2 | Scale

## 1) Goal
What user outcome are we enabling?

## 2) User story
As a <role>, I want <capability>, so that <benefit>.

## 3) UX flow (step-by-step)
- Step 1
- Step 2

## 4) Screens
List screens and main states (loading/empty/error/offline).

## 5) Data & API
### Entities
### Endpoints
### Permissions (RBAC/region)
### Offline behavior
Queue/caching rules.

## 6) Events & analytics
List event names and payload fields (redacted where needed).

## 7) Edge cases
- No internet
- Rate limit
- Partial data

## 8) Acceptance criteria
Bullet list.

## 9) Test plan
- Unit tests:
- Component tests:
- E2E tests:
- Contract tests (BFF):

## 10) Documentation updates
Which module docs, ADRs, runbooks to update.

## 11) Rollout
Feature flag? Migration steps? Backward compatibility?
