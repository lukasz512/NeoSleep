# SPECS INDEX (1–40)
This index lists all specs in execution-recommended order.
## Recommended execution order
- SPEC-0010 – Stage 0 CI gates + quality baseline
- SPEC-0002 – Google Workspace OIDC (Rep Auth)
- SPEC-0011 – Tenant config resolution in BFF
- SPEC-0003 – Notion Adapter + Cache Layer
- SPEC-0013 – Leads, HCP, HCO views (list+detail) with region scoping
- SPEC-0015 – Meeting lifecycle (start-stop) + context binding
- SPEC-0014 – Google Maps deep link (native navigation)
- SPEC-0004 – Offline Meeting Mode
- SPEC-0017 – PDF caching & preload flow
- SPEC-0016 – Offline sync UI (queue + retry)
- SPEC-0005 – PDF Player + Slide Tracking
- SPEC-0001 – Config-driven Post-Call Form (PCF)
- SPEC-0006 – i18n Pipeline (Real)
- SPEC-0007 – Email Engine (Transactional)
- SPEC-0008 – Event Logging + Sentry
- SPEC-0019 – OpenRouter integration wrapper + model pinning
- SPEC-0009 – Rep Copilot (AI Q&A)
- SPEC-0020 – Monthly insights report from rep questions
- SPEC-0031 – Data Schema Canonical Model (Type-First)
- SPEC-0034 – Environment Strategy (Dev - Staging - Prod)
- SPEC-0032 – Backup & Recovery Policy
- SPEC-0033 – Immutable Audit Log
- SPEC-0036 – Security Baseline Hardening
- SPEC-0035 – Performance Budget & Lighthouse CI
- SPEC-0037 – OpenAPI Contract Generation
- SPEC-0038 – Release & Version Governance
- SPEC-0039 – Data Retention & Deletion Policy
- SPEC-0040 – Deployment Portability (Cloud Agnostic)
- SPEC-0021 – Admin Panel - Tenant Config Editor
- SPEC-0022 – Dynamic Form Builder (PCF Builder)
- SPEC-0023 – Feature Flags Engine
- SPEC-0024 – HCP Portal Authentication (Magic Link)
- SPEC-0025 – HCP Portal - Document Access
- SPEC-0026 – Consent Management Module
- SPEC-0027 – Multi-Region Data Partitioning
- SPEC-0028 – Release Governance & AI Guard
- SPEC-0029 – Presentation Engagement Scoring v2
- SPEC-0030 – Self-Improvement Loop (AI Planning Engine)

## Notes
- Treat SPEC-0021+ as later phases (admin/portal).
